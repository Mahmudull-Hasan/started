<?php
/*
Plugin Name: Started Plugin
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: Essential CPT for Started Theme.
Author: Hasan Mahmud
Version: 1.0
Author URI: https://www.hmhasan.com

*/


// Register Custom Post type//

function started_custom_post_type() {

    // Slider Custom Post//
    $labels = array(
        'name'                  => _x( 'Sliders', 'Post type general name', 'started' ),
        'singular_name'         => _x( 'Slider', 'Post type singular name', 'started' ),
        'menu_name'             => _x( 'Sliders', 'Admin Menu text', 'started' ),
        'name_admin_bar'        => _x( 'Slider', 'Add New on Toolbar', 'started' ),
        'add_new'               => __( 'Add New Slider', 'started' ),
        'add_new_item'          => __( 'Add New Slider', 'started' ),
        'new_item'              => __( 'New Slider', 'started' ),
        'edit_item'             => __( 'Edit Slider', 'started' ),
        'view_item'             => __( 'View Slider', 'started' ),
        'all_items'             => __( 'All Sliders', 'started' ),
        'search_items'          => __( 'Search Slider', 'started' ),
        'parent_item_colon'     => __( 'Parent Sliders:', 'started' ),
        'not_found'             => __( 'No Slider found.', 'started' ),
        'not_found_in_trash'    => __( 'No Slider found in Trash.', 'started' ),
        'featured_image'        => _x( 'Slider Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'started' ),
        'set_featured_image'    => _x( 'Set Slider image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'started' ),
        'remove_featured_image' => _x( 'Remove Slider image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'started' ),
        'use_featured_image'    => _x( 'Use as Slider image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'started' ),
        'archives'              => _x( 'Sliders archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'started' ),
        'insert_into_item'      => _x( 'Insert into Slider', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'started' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this Slider', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'started' ),
        'filter_items_list'     => _x( 'Filter Slider list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'started' ),
        'items_list_navigation' => _x( 'Sliders list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'started' ),
        'items_list'            => _x( 'Slider list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'started' ),
    );     
    
    $args = array(
        'public'             => true,
        'labels'             => $labels,
        'menu_icon'          => 'dashicons-slides',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'sliders' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'thumbnail', 'custom-fields' ),
    );
    register_post_type( 'sliders', $args );

    //services custom post//
    $labels = array(
        'name'                  => _x( 'Services', 'Post type general name', 'started' ),
        'singular_name'         => _x( 'Services', 'Post type singular name', 'started' ),
        'menu_name'             => _x( 'Services', 'Admin Menu text', 'started' ),
        'name_admin_bar'        => _x( 'Service', 'Add New on Toolbar', 'started' ),
        'add_new'               => __( 'Add New Service', 'started' ),
        'add_new_item'          => __( 'Add New Service', 'started' ),
        'new_item'              => __( 'New Service', 'started' ),
        'edit_item'             => __( 'Edit Service', 'started' ),
        'view_item'             => __( 'View Service', 'started' ),
        'all_items'             => __( 'All Services', 'started' ),
        'search_items'          => __( 'Search Service', 'started' ),
        'parent_item_colon'     => __( 'Parent Services:', 'started' ),
        'not_found'             => __( 'No Service found.', 'started' ),
        'not_found_in_trash'    => __( 'No Service found in Trash.', 'started' ),
        
    );     
    
    $args = array(
        'public'             => true,
        'labels'             => $labels,
        'menu_icon'          => 'dashicons-groups',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'services' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'custom-fields' ),
    );
    register_post_type( 'services', $args );



    // Prices custom post//

    $labels = array(
        'name'                  => _x( 'Prices', 'Post type general name', 'started' ),
        'singular_name'         => _x( 'Price', 'Post type singular name', 'started' ),
        'menu_name'             => _x( 'Prices', 'Admin Menu text', 'started' ),
        'name_admin_bar'        => _x( 'Price', 'Add New on Toolbar', 'started' ),
        'add_new'               => __( 'Add New Price', 'started' ),
        'add_new_item'          => __( 'Add New Price', 'started' ),
        'new_item'              => __( 'New Price', 'started' ),
        'edit_item'             => __( 'Edit Price', 'started' ),
        'view_item'             => __( 'View Price', 'started' ),
        'all_items'             => __( 'All Prices', 'started' ),
        'search_items'          => __( 'Search Price', 'started' ),
        'parent_item_colon'     => __( 'Parent Prices:', 'started' ),
        'not_found'             => __( 'No Price found.', 'started' ),
        'not_found_in_trash'    => __( 'No Price found in Trash.', 'started' ),
        
    );     
    
    $args = array(
        'public'             => true,
        'labels'             => $labels,
        'menu_icon'          => 'dashicons-editor-contract',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'prices' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array('title', 'custom-fields'),
    );
    register_post_type( 'prices', $args );


    // Testimonials custom post//

    $labels = array(
        'name'                  => _x( 'Testimonials', 'Post type general name', 'started' ),
        'singular_name'         => _x( 'Testimonial', 'Post type singular name', 'started' ),
        'menu_name'             => _x( 'Testimonials', 'Admin Menu text', 'started' ),
        'name_admin_bar'        => _x( 'Testimonial', 'Add New on Toolbar', 'started' ),
        'add_new'               => __( 'Add New', 'started' ),
        'add_new_item'          => __( 'Add New', 'started' ),
        'new_item'              => __( 'New Testimonial', 'started' ),
        'edit_item'             => __( 'Edit Testimonial', 'started' ),
        'view_item'             => __( 'View Testimonial', 'started' ),
        'all_items'             => __( 'All Testimonials', 'started' ),
        'search_items'          => __( 'Search Testimonial', 'started' ),
        'parent_item_colon'     => __( 'Parent Testimonials:', 'started' ),
        'not_found'             => __( 'No Testimonial found.', 'started' ),
        'not_found_in_trash'    => __( 'No Testimonial found in Trash.', 'started' ),
        
    );     
    
    $args = array(
        'public'             => true,
        'labels'             => $labels,
        'menu_icon'          => 'dashicons-testimonial',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'testimonials' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array('title', 'custom-fields'),
    );
    register_post_type( 'testimonials', $args );



    // Team Section custom post//

    $labels = array(
        'name'                  => _x( 'Teams', 'Post type general name', 'started' ),
        'singular_name'         => _x( 'Team', 'Post type singular name', 'started' ),
        'menu_name'             => _x( 'Teams', 'Admin Menu text', 'started' ),
        'name_admin_bar'        => _x( 'Team', 'Add New on Toolbar', 'started' ),
        'add_new'               => __( 'Add New', 'started' ),
        'add_new_item'          => __( 'Add New', 'started' ),
        'new_item'              => __( 'New Team', 'started' ),
        'edit_item'             => __( 'Edit Team', 'started' ),
        'view_item'             => __( 'View Team', 'started' ),
        'all_items'             => __( 'All Testimonials', 'started' ),
        'search_items'          => __( 'Search Team', 'started' ),
        'parent_item_colon'     => __( 'Parent Testimonials:', 'started' ),
        'not_found'             => __( 'No Team found.', 'started' ),
        'not_found_in_trash'    => __( 'No Team found in Trash.', 'started' ),
        
    );     
    
    $args = array(
        'public'             => true,
        'labels'             => $labels,
        'menu_icon'          => 'dashicons-buddicons-buddypress-logo',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'team' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array('title', 'custom-fields', 'thumbnail'),
    );
    register_post_type( 'team', $args );
}
add_action( 'init', 'started_custom_post_type' );